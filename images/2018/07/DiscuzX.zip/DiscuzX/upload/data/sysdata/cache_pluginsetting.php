<?php
//Discuz! cache file, DO NOT modify me!
//Identify: 7ad0784ef0e9b7238c6476335acafcab

$pluginsetting = array (
);
?>